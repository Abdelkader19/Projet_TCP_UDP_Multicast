import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Objects;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        String nom;
        int serverPort = 9870;
        String serverHost = "localhost";
        System.out.print("Enter Your Full name: ");
        Scanner s = new Scanner(System.in);
        nom = s.nextLine();
        System.out.println("Welcome "+nom+", send a message to join the conversation");
        try {
            DatagramSocket socket = new DatagramSocket();
            InetAddress serverAddress = InetAddress.getByName(serverHost);

            // Thread for receiving messages from the server
            Thread receiveThread = new Thread(() -> {
                try {
                    while (true) {
                        byte[] receiveData = new byte[1024];
                        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                        socket.receive(receivePacket);
                        String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
                        System.out.println(response);
                    }
                } catch (IOException e) {

                }
            });
            receiveThread.start();

            // Thread for sending messages to the server
            while (true) {
                Scanner clavier = new Scanner(System.in);
                String message = clavier.nextLine();

                if (Objects.equals(message, "exit")) {
                    socket.close();
                    break;
                } else {
                    byte[] data = (nom + ": " + message).getBytes();
                    DatagramPacket packet = new DatagramPacket(data, data.length, serverAddress, serverPort);
                    socket.send(packet);
                }
            }
        } catch (IOException e) {

        }
    }
}
