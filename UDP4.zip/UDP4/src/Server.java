import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;

public class Server {
    private static final int serverPort = 9870;
    private static ArrayList<Integer> clients = new ArrayList<>();

    public static void main(String[] args) {
        try {
            DatagramSocket socket = new DatagramSocket(serverPort);
            System.out.println("UDP Server is running on port " + serverPort);

            while (true) {
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();
                if (!clients.contains(clientPort)) {
                    clients.add(clientPort); // Add client address to the list if not present
                }

                byte[] data = receivePacket.getData();
                String message = new String(data, 0, receivePacket.getLength());
                System.out.println("Received from " + clientAddress + ":" + clientPort + " - " + message);

                // Broadcast the message to all connected clients
                for (int client : clients) {
                    byte[] responseData = message.getBytes();
                    DatagramPacket responsePacket = new DatagramPacket(responseData, responseData.length, clientAddress, client);
                    socket.send(responsePacket);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
