import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;


public class Server {
    public static int PORT = 1234;
    private ServerSocket serverSocket;

    public Server(ServerSocket serverSocket) {
        this.serverSocket = serverSocket;
    }

    public void startServer() {
        System.out.println("Serveur en écoute sur le port " + PORT);

        try {
            while (!serverSocket.isClosed()) {
                Socket socket = serverSocket.accept();
                System.out.println("A new client has connected");
                ClientHandler clientHandler = new ClientHandler(socket);
                clientHandler.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(PORT);
        Server server = new Server(serverSocket);
        server.startServer();
    }
    private static class ClientHandler extends Thread {

        public static ArrayList<ClientHandler> clientHandlers = new ArrayList<>();
        private Socket socket;
        private BufferedReader bufferedReader;
        private BufferedWriter bufferedWriter;
        private String clientUsername;

        public ClientHandler(Socket socket) {
            try {
                this.socket = socket;
                this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
                this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                this.clientUsername = bufferedReader.readLine();
                clientHandlers.add(this);
                broadcastMessage(  clientUsername + " has entered the chat");
            } catch (IOException e) {
                closeEverything();
            }
        }
        private void broadcastMessage(String messageToSend) {
            for (ClientHandler clientHandler : clientHandlers) {
                try {
                    if (!clientHandler.clientUsername.equals(clientUsername)) {
                        clientHandler.bufferedWriter.write(messageToSend);
                        clientHandler.bufferedWriter.newLine();
                        clientHandler.bufferedWriter.flush();
                    }
                } catch (IOException e) {
                    closeEverything();
                }
            }
        }
        private void sendPrivateMessage(String sender, String recipient, String message) {
            for (ClientHandler clientHandler : clientHandlers) {
                try {
                    if (clientHandler.clientUsername.equals(recipient)) {
                        clientHandler.bufferedWriter.write(sender+": "+message);
                        clientHandler.bufferedWriter.newLine();
                        clientHandler.bufferedWriter.flush();
                    }
                } catch (IOException e) {
                    closeEverything();
                }
            }
        }
        @Override
        public void run() {
            String message;
            while (socket.isConnected()) {
                try {
                    message = bufferedReader.readLine();
                    if ("exit".equals(message)) {
                        // If the client wants to exit, remove it from the map and broadcast the exit message
                        removeClientHandler();
                        break;
                    } else if (message.startsWith("@")) {
                        // If the message starts with '@', it is a private message to a specific client
                        String[] parts = message.split(" ", 2);
                        String recipient = parts[0].substring(1);
                        String privateMessage = parts[1];
                        sendPrivateMessage(clientUsername, recipient, privateMessage);
                    } else {
                        // Broadcast the message to all clients
                        broadcastMessage(clientUsername+": " +message);
                    }
                } catch (IOException e) {
                    closeEverything();
                    break;
                }
            }
        }

        private void closeEverything() {
            removeClientHandler();
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (bufferedWriter != null) {
                    bufferedWriter.close();
                }
                if (socket != null && !socket.isClosed()) {
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void removeClientHandler() {
            clientHandlers.remove(this);
            System.out.println("A client has left the chat");
            broadcastMessage(  clientUsername + " has left");
        }

    }
}
