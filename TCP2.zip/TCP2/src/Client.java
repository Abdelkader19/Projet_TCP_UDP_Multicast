import java.io.*;
import java.net.*;
import java.util.Objects;
import java.util.Scanner;

import static java.lang.System.exit;


public class Client {
    private Socket socket;
    private BufferedReader bufferedReader;
    private BufferedWriter bufferedWriter;
    private String username;


    public Client(Socket socket, String username) {
        try {
            this.socket = socket;
            this.bufferedWriter = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.username = username;

        } catch(IOException e) {
            closeEverything(socket);
        }
    }
    public void sendMessage() { //envoyer des messages
        try {
            bufferedWriter.write(username);
            bufferedWriter.newLine();
            bufferedWriter.flush();  //force l'écriture de toutes les données en attente

            Scanner scanner = new Scanner(System.in); // lit les messages depuis la console
            while (!socket.isClosed()) {
                String messageToSend = scanner.nextLine();
                bufferedWriter.write(messageToSend);
                bufferedWriter.newLine();
                bufferedWriter.flush();
                if (messageToSend.equals("exit")){
                    closeEverything(socket);
                }

            }
        }catch (IOException e) {
            closeEverything(socket);
        }
    }
    public void listenForMessage() {  //tesma3 les messages entrants
        new Thread(new Runnable() {

            @Override
            public void run() {
                String msgFromGroupChat;
                while(!socket.isClosed()) {
                    try {
                        if(socket.isClosed())break;
                        msgFromGroupChat = bufferedReader.readLine();  //crée un thread séparé qui lit les messages
                        System.out.println(msgFromGroupChat);
                    }catch(IOException e) {
                        closeEverything(socket);
                    }
                }
            }

        }).start();
    }
    public void closeEverything(Socket socket) {
            try {

                    socket.close();


            }catch(IOException e) {
                e.printStackTrace();
            }
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter your username for the group chat: ");
        String username = scanner.nextLine();
        try {
            Socket socket = new Socket("localhost", 1234);
            Client client = new Client(socket, username);
            client.listenForMessage();
            client.sendMessage();

        } catch (ConnectException e) {
            System.err.println("Unable to connect to the server. Make sure the server is running on localhost:1234.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}






