import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.io.IOException;
import java.util.Scanner;


public class MulticastReceiver extends Thread {
    public static void main(String[] args) throws IOException {
        try {
            Scanner s = new Scanner(System.in);
            MulticastSocket socket = new MulticastSocket(4446);
            InetAddress group = InetAddress.getByName("230.0.0.0");
            byte[] buf = new byte[256];
            socket.joinGroup(group);
            Thread quit = new Thread(() -> {
                try {
                    while (true) {
                        String userInput = s.nextLine();
                        if ("q".equalsIgnoreCase(userInput)) {
                            socket.leaveGroup(group);
                            socket.close();
                            break;
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });

            quit.start();
            while (true) {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);
                String received = new String(packet.getData(), 0, packet.getLength());
                System.out.println(received);
            }
        }catch (IOException ex) {

        }
    }
}