import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Objects;
import java.util.Scanner;

public class MulticastPublisher {
    public static void main(String[] args) throws IOException {
        DatagramSocket socket = new DatagramSocket();
        InetAddress group = InetAddress.getByName("230.0.0.0");
        while(true) {
            System.out.println("Type Multicast message:");
            Scanner s = new Scanner(System.in);
            String multicastMessage = s.nextLine();
            byte[] buf = multicastMessage.getBytes();
            DatagramPacket packet = new DatagramPacket(buf, buf.length, group, 4446);
            socket.send(packet);
            if(Objects.equals(multicastMessage, "end")){
                break;
            }
        }
        socket.close();
    }
}